
const namespace = {
    "app_modes": "smod"
}

export default namespace;