
const privileges = {
    "staff.manage":"STAFF.MANAGE",
}

export default privileges;