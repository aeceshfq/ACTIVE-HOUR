const scopes = [
    "STAFF.MANAGE",
];

module.exports = scopes;
