module.exports = {
    connection: `${process.env.DATABASE_STRING}`
}