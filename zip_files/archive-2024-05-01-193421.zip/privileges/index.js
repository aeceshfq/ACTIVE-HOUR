
const privileges = {
    "staff.manage":"STAFF.MANAGE",
}

module.exports = privileges;